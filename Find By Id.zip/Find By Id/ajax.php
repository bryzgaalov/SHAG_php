<?php

$number = 0;

if (isset($_POST['number'])) {
    $number = $_POST['number'];
} else {
    echo "Нет Number";
}

if ($number > 30) {
    echo "Цифра больше 30";
} else if ($number < 30) {
    echo "Цифра меньше 30";
}