<?php

$hostname = 'localhost';
$user     = 'user';
$password = 'user';
$db_name  = 'php';

$mysql = mysqli_connect($hostname, $user, $password, $db_name);
if (!$mysql) {
    echo "ERROR DB";
} else {
    $date      = date('Y-m-d');
    $sql_query = "SELECT * FROM PRODUCT;";
    $result    = mysqli_query($mysql, $sql_query);

    $error = mysqli_error($mysql);
    if ($error == '') {
        while ($product = mysqli_fetch_array($result)) {
            echo $product['name'] . '<BR>';
            echo $product['price'] . '<BR>';
            echo $product['created_at'] . '<BR>';
        }
    } else {
        echo $error;
    }

    mysqli_close($mysql);
}

//session_start();
//
//if (!isset($_SESSION['count1'])) {
//    $_SESSION['count1'] = 0;
//}
//if (!isset($_SESSION['count2'])) {
//    $_SESSION['count2'] = 0;
//}
//
//if (isset($_POST['btn1'])) {
//    $_SESSION['count1']++;
//}
//if (isset($_POST['btn2'])) {
//    $_SESSION['count2']++;
//}
//
//$btn1_count = $_SESSION['count1'];
//$btn2_count = $_SESSION['count2'];
//
//if (isset($_POST['destroy'])) {
//    session_destroy();
//    $btn1_count = 0;
//    $btn2_count = 0;
//}
//
//setcookie('country', 'asdasd', -1);
////unset($_COOKIE['country']);
//
////session_destroy();
//?>
    <!---->
    <!--    <html>-->
    <!--    <head>-->
    <!--        <title></title>-->
    <!--    </head>-->
    <!--    <body>-->
    <!--    <form action="index.php" method="POST">-->
    <!--        <button type="submit" name="btn1">BTN1</button>-->
    <!--    </form>-->
    <!--    <form action="index.php" method="POST">-->
    <!--        <button type="submit" name="btn2">BTN2</button>-->
    <!--    </form>-->
    <!--    <form action="index.php" method="POST">-->
    <!--        <button type="submit" name="destroy">Очистить сессию</button>-->
    <!--    </form>-->
    <!---->
    <!--    <br><br>-->
    <!--    Количество кликов BTN1: --><? //= $btn1_count ?>
    <!--    <br>-->
    <!--    Количество кликов BTN2: --><? //= $btn2_count ?>
    <!--    </body>-->
    <!--    </html>-->
    <!---->
<?php
//var_dump($_SESSION);
//echo '<br>';
//var_dump($_COOKIE);
//
//?>
    <!---->

<?php
//
//class Person {
//
//    public $firstname;
//    public $lastname;
//    public $middlename;
//    public $age;
//    public $status;
//
//    const STATUS_ACTIVE     = 1;
//    const STATUS_NOT_ACTIVE = 0;
//
//    public function __construct() {
//        $this->firstname  = 'Name';
//        $this->lastname   = 'LastName';
//        $this->middlename = 'MiddleName';
//        $this->age        = rand(1, 100);
//        $this->status     = self::STATUS_ACTIVE;
//    }
//
//    protected function closedMethod() {
//        echo "I am closed method";
//    }
//
//    public function sayHello() {
//        echo 'Hello! I am '
//             . $this->firstname
//             . ' ' .
//             $this->lastname;
//    }
//
//    public function getFullName() {
//        return $this->lastname;
//    }
//
//    public static function getPersonClassInfo() {
//        echo 'Этот класс для сущности Клиента';
//    }
//
//}
//
//$personModel = new Person('Альбек', 'Ермек', '', 27);
//Person::getPersonClassInfo();
//$personModel->sayHello();
//
//class Man extends Person {
//    public function hello() {
//        echo $this->getFullName();
//    }
//}
//
//class Woman extends Man {
//
//}
//
////$childClassOfPerson = new Man('Альбек', 'Ермек', '', 27);
//$child2 = new Woman('Альбек', 'Ермек', '', 27);
////
////echo $childClassOfPerson->sayHello();
////echo $childClassOfPerson->hello();
//$parentClassesOfWoman = class_parents($child2);
//echo "<br>";
//foreach ($parentClassesOfWoman as $item) {
//
//    $class_object = new $item;
//
//    if (is_subclass_of($class_object, 'Person')) {
//        echo 'Class: ' . get_class($class_object) . ' is Subclass of Person <br>';
//    } else {
//        echo 'Class: ' . get_class($class_object) . ' is not Subclass of Person <br>';
//    }
//}
//
//$arr = [1,'asdasd',3];
//
//foreach ($arr as $item) {
//    echo $item . '<BR>';
//}
//
//$arr[] = 'ZXC';
//
//echo "AFTER: <BR>";
//
//foreach ($arr as $item) {
//    echo $item . '<BR>';
//}
//
//
//echo phpinfo();
//
//abstract class Car
//{
//    abstract public function Drive($speed);
//    abstract public function Signal();
//    public function Stop() {
//        echo 123;
//    }
//}

//interface ChildCar extends Car {
//    public function Repair();
//}
//
//class Toyota extends Car {
//
//    public $model;
//
//    public function __construct($car_model) {
//        $this->model = $car_model;
//    }
//
//    public function Drive($speed) {
//        echo "$this->model: Speed is $speed km/hour";
//    }
//
//    public function Signal() {
//        echo "$this->model: BEEEP!";
//    }
//
////    public function Stop() {
////        echo "$this->model: is stopping...stopped";
////    }
//
//    public function Repair() {
//        // TODO: Implement Repair() method.
//    }
//}
//
//$carCorolla = new Toyota('Corolla');
//
//$carCorolla->Drive(40);
//$carCorolla->Signal();
//$carCorolla->Stop();

/**
 *
 * Client class
 *
 * name
 * surname
 *
 * Account class
 *
 * moneyKZT
 * moneyUSD
 * moneyRUB
 *
 * accountAdd($currency, $amount)
 * accountSub($currency, $amount)
 * getBalance($currency)
 *
 */
//
//$questions_database = [
//    [
//        'name'           => 'PHP это - ',
//        'point'          => 5,
//        'answers'        => ['a' => 'Язык программирования', 'b' => 'Слон'],
//        'correct_answer' => 'a',
//    ],
//    [
//        'name'           => 'Массив это - ',
//        'point'          => 3,
//        'answers'        => ['a' => 'строка', 'b' => 'Набор данных'],
//        'correct_answer' => 'b',
//    ],
//    [
//        'name'           => 'Interger это - ',
//        'point'          => 2,
//        'answers'        => ['a' => 'Массив из чисел', 'b' => 'Цифра'],
//        'correct_answer' => 'b',
//    ],
//];
//
//interface ITest {
//    public function init($questions_database);
//
//    public function startTest();
//
//    public function getAnswers(array $answers);
//
//    public function getResult();
//}
//
//class Question {
//    public $name;
//    public $point;
//    public $answers = [];
//    public $correct_answer;
//
//    public function __construct($name, $point, $answers, $correct_answer) {
//        $this->name           = $name;
//        $this->point          = $point;
//        $this->answers        = $answers;
//        $this->correct_answer = $correct_answer;
//    }
//}
//
//class Test implements ITest {
//    public $points;
//    public $questions               = [];
//    public $number_of_right_answers = 0;
//
//    /**
//     * @param $questions_database
//     */
//    public function init($questions_database) {
//
//        foreach ($questions_database as $item) {
//            $questionObject = new Question(
//                $item['name'],
//                $item['point'],
//                $item['answers'],
//                $item['correct_answer']);
//
//            $this->questions[] = $questionObject;
//        }
//    }
//
//    public function startTest() {
//        echo "Начало теста: <br>";
//        foreach ($this->questions as $index => $question) {
//            echo ($index + 1) . " вопрос: $question->name <br>";
//            echo "Варианты ответа: <br>";
//            foreach ($question->answers as $key => $answer) {
//                echo "$key) - $answer <br>";
//            }
//            echo "<br>";
//        }
//    }
//
//    public function getAnswers(array $answers) { //['a','a','a','a']
//
//        $this->points = 0;
//        foreach ($answers as $key => $answer) {
//            $current_question = $this->questions[$key];
//
//            if ($current_question->correct_answer == $answer) {
//                $this->points += $current_question->point;
//                $this->number_of_right_answers++;
//            }
//        }
//    }
//
//    public function getResult() {
//        $number_of_questions = count($this->questions);
//        echo "<br> Правильных ответов: $this->number_of_right_answers из $number_of_questions <br>";
//        echo "Баллов заработал: $this->points";
//    }
//}
//
//$test = new Test();
//$test->init($questions_database);
//$test->startTest();
//$test->getAnswers(['a','b','a','a']);
//$test->getResult();

?>
    <!--//index.php-->
    <!--<html>-->
    <!--<body>-->
    <!--<form action="file.php" method="POST" enctype="multipart/form-data">-->
    <!--    <input type="text" value="" title="Text" name="text">-->
    <!--    <br>-->
    <!--    <input type="file" name="myfile[]">-->
    <!--    <br>-->
    <!--    <input type="file" name="myfile[]">-->
    <!--    <br>-->
    <!--    <input type="file" name="myfile[]">-->
    <!--    <br>-->
    <!--    <button type="submit">Submit</button>-->
    <!--</form>-->
    <!--</body>-->
    <!--</html>-->
    <!---->
    <!--//file.php-->
<?php
//
//if (!is_dir('uploads')) {
//    mkdir('uploads');
//}
//
//foreach ($_FILES['myfile']['name'] as $index => $filename) {
//    move_uploaded_file(
//        $_FILES['myfile']['tmp_name'][$index],
//        'uploads/' . $filename
//    );
//}
//
?>