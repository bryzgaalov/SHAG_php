<?php

$hostname = 'localhost';
$user     = 'user';
$password = 'user';
$db_name  = 'phpdb';

$mysql = mysqli_connect($hostname, $user, $password, $db_name);
if (!$mysql) {
    echo "ERROR DB";
} else {

    $name  = $_POST['name'] ?? null;
    $price = $_POST['price'] ?? null;

    if ($name !== null && $price !== null) {
        $date  = date('Y-m-d');
        $price = intval($price);

        $sql_query = "INSERT INTO PRODUCT 
    (name, price, created_at) 
    VALUES ('$name', $price, '$date')";

        $result = mysqli_query($mysql, $sql_query);
        $error  = mysqli_error($mysql);

        if ($error == '') {
            echo "OK";
        } else {
            echo $error;
        }
    }

    mysqli_close($mysql);
}