<?php

$hostname = 'localhost';
$user     = 'user';
$password = 'user';
$db_name  = 'phpdb';

$mysql = mysqli_connect($hostname, $user, $password, $db_name);
if (!$mysql) {
    echo "ERROR DB";
} else {
    $sql_query = "SELECT * FROM PRODUCT;";
    $result    = mysqli_query($mysql, $sql_query);

    $error = mysqli_error($mysql);
    if ($error == '') {
        echo "<table>";
        echo "<tr>
                <td>ID</td> 
                <td>Наименование</td>
                <td>Цена</td>
                <td>Дата создания</td>
              </tr>";
        while ($product = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $product['id'] . '</td>';
            echo "<td>" . $product['name'] . '</td>';
            echo "<td>" . $product['price'] . '</td>';
            echo "<td>" . $product['created_at'] . '</td>';
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo $error;
    }

    mysqli_close($mysql);
}