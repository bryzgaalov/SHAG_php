<?php

$hostname = 'localhost';
$user     = 'user';
$password = 'user';
$db_name  = 'phpdb';

$mysql = mysqli_connect($hostname, $user, $password, $db_name);
if (!$mysql) {
    echo "ERROR DB";
} else {

    $id    = $_POST['id'] ?? null;
    $name  = $_POST['name'] ?? null;
    $price = $_POST['price'] ?? null;

    if ($id !== null && $name !== null && $price !== null) {
        $date  = date('Y-m-d');
        $id    = intval($id);
        $price = intval($price);

        $sql_query = "UPDATE PRODUCT 
SET name = '$name', price = $price 
WHERE id = $id";

        $result = mysqli_query($mysql, $sql_query);
        $error  = mysqli_error($mysql);

        if ($error == '') {
            echo "OK";
        } else {
            echo $error;
        }
    }

    mysqli_close($mysql);
}