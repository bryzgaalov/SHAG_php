<?php

$hostname = 'localhost';
$user     = 'user';
$password = 'user';
$db_name  = 'phpdb';

$mysql = mysqli_connect($hostname, $user, $password, $db_name);
if (!$mysql) {
    echo "ERROR DB";
} else {

    $id  = $_POST['id'] ?? null;

    if ($id !== null) {
        $id = intval($id);

        $sql_query = "DELETE FROM PRODUCT WHERE id = $id;";

        $result = mysqli_query($mysql, $sql_query);
        $error  = mysqli_error($mysql);

        if ($error == '') {
            echo "OK";
        } else {
            echo $error;
        }
    }

    mysqli_close($mysql);
}